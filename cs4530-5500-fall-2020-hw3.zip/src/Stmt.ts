import ASTNode from './ASTNode'

/**
 * root of the statement subhierarchy.  
 */
interface Stmt extends ASTNode {
   
}

export default Stmt